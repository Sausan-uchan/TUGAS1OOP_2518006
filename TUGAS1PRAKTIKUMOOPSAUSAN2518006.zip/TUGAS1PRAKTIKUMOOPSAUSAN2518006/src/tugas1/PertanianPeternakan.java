package tugas1;

/**
 * Class PertanianPeternakan
 * Menyimpan data pertanian dan peternakan
 */
public class PertanianPeternakan {
    
    // ====================
    // Atribut
    // ====================
    String nama;
    String jenis;
    int jumlahAwal;
    int jumlah;

    // ====================
    // Constructor
    // ====================
    /**
     * Constructor untuk inisialisasi data awal
     */
    public PertanianPeternakan(String nama, String jenis, int jumlahAwal) {
        this.nama = nama;
        this.jenis = jenis;
        this.jumlahAwal = jumlahAwal;
        this.jumlah = jumlahAwal;
    }

    // ====================
    // Method
    // ====================

    /**
     * Method untuk proses penjualan (dengan validasi)
     */
    public void prosesPenjualan(int penjualan) {
        if (penjualan > jumlah) {
            System.out.println("Penjualan melebihi stok!");
        } else {
            jumlah -= penjualan;
        }
    }

    /**
     * Method untuk menentukan satuan
     */
    public String getSatuan() {
        if (jenis.equalsIgnoreCase("Pertanian")) return "kilo";
        else if (jenis.equalsIgnoreCase("Peternakan")) return "ekor";
        else return "";
    }

    /**
     * Method untuk menghitung jumlah terjual
     */
    public int getJumlahTerjual() {
        return jumlahAwal - jumlah;
    }

    /**
     * Method untuk menghitung persentase penjualan
     */
    public double getPersentaseTerjual() {
        if (jumlahAwal == 0) return 0;
        return (getJumlahTerjual() * 100.0) / jumlahAwal;
    }

    /**
     * Method untuk cek status stok
     */
    public String cekStatus() {
        if (jumlah == 0) return "Habis";
        else if (jumlah < jumlahAwal / 2) return "Hampir Habis";
        else return "Masih Banyak";
    }

    /**
     * Method untuk menampilkan data lengkap
     */
    public void tampilkanData() {
        System.out.println("Nama           : " + nama);
        System.out.println("Jenis          : " + jenis);
        System.out.println("Jumlah Awal    : " + jumlahAwal + " " + getSatuan());
        System.out.println("Terjual        : " + getJumlahTerjual() + " " + getSatuan());
        System.out.println("Sisa           : " + jumlah + " " + getSatuan());
        System.out.println("Persentase     : " + getPersentaseTerjual() + "%");
        System.out.println("Status Stok    : " + cekStatus());
        System.out.println("------------------------");
    }
}