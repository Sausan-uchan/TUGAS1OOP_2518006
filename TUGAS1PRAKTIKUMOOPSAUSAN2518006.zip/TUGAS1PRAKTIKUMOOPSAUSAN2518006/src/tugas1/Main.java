package tugas1;

import java.util.Scanner;

/**
 * Driver class untuk program Pertanian dan Peternakan
 */
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("=== DATA PERTANIAN ===");
        System.out.print("Masukkan Nama: ");
        String namaPertanian = input.nextLine();
        System.out.print("Masukkan Jenis: ");
        String jenisPertanian = input.nextLine();
        System.out.print("Masukkan Jumlah Awal (kg): ");
        int jumlahAwalPertanian = input.nextInt();
        System.out.print("Masukkan Penjualan Hari Ini (kg): ");
        int penjualanPertanian = input.nextInt();
        input.nextLine(); // clear newline

        System.out.println("\n=== DATA PETERNAKAN ===");
        System.out.print("Masukkan Nama: ");
        String namaPeternakan = input.nextLine();
        System.out.print("Masukkan Jenis: ");
        String jenisPeternakan = input.nextLine();
        System.out.print("Masukkan Jumlah Awal (ekor): ");
        int jumlahAwalPeternakan = input.nextInt();
        System.out.print("Masukkan Penjualan Hari Ini (ekor): ");
        int penjualanPeternakan = input.nextInt();

        // Membuat object
        PertanianPeternakan pertanian = new PertanianPeternakan(namaPertanian, jenisPertanian, jumlahAwalPertanian);
        PertanianPeternakan peternakan = new PertanianPeternakan(namaPeternakan, jenisPeternakan, jumlahAwalPeternakan);

        // Proses penjualan
        pertanian.prosesPenjualan(penjualanPertanian);
        peternakan.prosesPenjualan(penjualanPeternakan);

        // Tampilkan hasil akhir
        System.out.println("\n=== HASIL AKHIR ===");
        pertanian.tampilkanData();
        peternakan.tampilkanData();

        input.close();
    }
}