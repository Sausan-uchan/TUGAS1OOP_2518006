/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manajemenpertanian;

/**
 *
 * @author SAUSAN SYAFIQAH
 */
public class Pertanian {
    private String jenisTanaman;
    private double luasLahan;
    private double hasilPerHektar;

    public Pertanian(String jenisTanaman, double luasLahan, double hasilPerHektar) {
        this.jenisTanaman = jenisTanaman;
        this.luasLahan = luasLahan;
        this.hasilPerHektar = hasilPerHektar;
    }

    public double hitungTotalPanen() {
        return luasLahan * hasilPerHektar;
    }

    public void tampilkanPertanian() {
        System.out.println("Jenis Tanaman : " + jenisTanaman);
        System.out.println("Total Panen   : " + hitungTotalPanen() + " kg");
    }
}
