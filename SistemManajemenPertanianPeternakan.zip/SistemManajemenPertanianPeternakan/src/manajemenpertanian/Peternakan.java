/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manajemenpertanian;

/**
 *
 * @author SAUSAN SYAFIQAH
 */
public class Peternakan {
    private String jenisTernak;
    private int jumlahTernak;
    private double produksiPerEkor;

    public Peternakan(String jenisTernak, int jumlahTernak, double produksiPerEkor) {
        this.jenisTernak = jenisTernak;
        this.jumlahTernak = jumlahTernak;
        this.produksiPerEkor = produksiPerEkor;
    }

    public double hitungProduksi() {
        return jumlahTernak * produksiPerEkor;
    }

    public void tampilkanPeternakan() {
        System.out.println("Jenis Ternak    : " + jenisTernak);
        System.out.println("Total Produksi  : " + hitungProduksi());
    }
}
