package manajemenpertanian;

import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("=== SISTEM MANAJEMEN PERTANIAN & PETERNAKAN ===");

        System.out.print("Nama Petani : ");
        String nama = input.nextLine();

        System.out.print("Alamat : ");
        String alamat = input.nextLine();

        Petani petani = new Petani(nama, alamat);

        System.out.print("Jenis Tanaman : ");
        String tanaman = input.nextLine();

        System.out.print("Luas Lahan : ");
        double luas = input.nextDouble();

        System.out.print("Hasil per Hektar : ");
        double hasil = input.nextDouble();

        Pertanian pertanian = new Pertanian(tanaman, luas, hasil);

        input.nextLine();

        System.out.print("Jenis Ternak : ");
        String ternak = input.nextLine();

        System.out.print("Jumlah Ternak : ");
        int jumlah = input.nextInt();

        System.out.print("Produksi per Ekor : ");
        double produksi = input.nextDouble();

        Peternakan peternakan = new Peternakan(ternak, jumlah, produksi);

        System.out.print("Harga Panen per Kg : ");
        double hargaPanen = input.nextDouble();

        System.out.print("Harga Produk Ternak : ");
        double hargaProduk = input.nextDouble();

        ManajemenUsaha usaha = new ManajemenUsaha();

        double totalPendapatan = usaha.hitungPendapatan(
                pertanian.hitungTotalPanen(),
                peternakan.hitungProduksi(),
                hargaPanen,
                hargaProduk
        );

        System.out.println("\n=== DATA USAHA ===");

        petani.tampilkanPetani();
        pertanian.tampilkanPertanian();
        peternakan.tampilkanPeternakan();

        System.out.println("Total Pendapatan : Rp " + totalPendapatan);

    }
}