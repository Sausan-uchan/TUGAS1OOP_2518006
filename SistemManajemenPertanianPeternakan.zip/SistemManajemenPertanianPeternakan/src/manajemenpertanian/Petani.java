/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manajemenpertanian;

/**
 *
 * @author SAUSAN SYAFIQAH
 */
public class Petani {
    private String nama;
    private String alamat;

    public Petani(String nama, String alamat) {
        this.nama = nama;
        this.alamat = alamat;
    }

    public void tampilkanPetani() {
        System.out.println("Nama Petani : " + nama);
        System.out.println("Alamat      : " + alamat);
    }
}
