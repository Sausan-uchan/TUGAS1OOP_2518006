/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manajemenpertanian;

/**
 *
 * @author SAUSAN SYAFIQAH
 */
public class ManajemenUsaha {
    public double hitungPendapatan(double panen, double produksi, double hargaPanen, double hargaProduk) {

        double pendapatanPanen = panen * hargaPanen;
        double pendapatanTernak = produksi * hargaProduk;

        return pendapatanPanen + pendapatanTernak;
    }

}
